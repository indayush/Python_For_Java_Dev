# Python_For_Java_Dev
# Author - Ayush Adarsh

Hi All,
This project is my consolidated work from several trainings sessions that i went through or going through to learn Python.
I thank all the trainers that made their content available for people. I will credit them below. Feel free to visit their page and post your appreciation.

Python Basics for Java Developers by Mrs. Deepa Muralidhar (This is where i started from)
https://www.linkedin.com/learning/python-basics-for-java-developers

Python Tutorial for beginners by Mr. Kumar Kaushik (Highly Recommend if wanna learn more about theory too. It's in Hindi language though)
https://youtu.be/aalQrDq1UkI

Learning Python by Mr. Joe Marini (Great for practicing)
https://www.linkedin.com/learning/learning-python-2/