# File for testing concepts before putting them finally in the respective files

print("Enter the name of Acc. holder - ")
print(input()) 