print("Hello")
print ("Hello")

print('Hello')
print ('Hello')

# My Observations -                      - # is for single line comment
'''                                      - this is for multi line comment. It is like /* ....*/ in java
Capital P not allowed for print
Both Single & double quotes supported in functions for strings

'''