# Deepa Muralidhar
# Date
#Name of prgram

print ("There are some statements in a python program that start with # symbol - a hash tag. They are comments")
# This is an example of a comment
print ("Sometimes you can use ''' symbols before and after mulitple program statements. This will comment the entire block")
print ("This is called block commenting or doc string")
"""
print("This is the 1st line that commented. Which means it will not be compiled")
print ("This is the 2nd line that is commmented. Which means this also will not be complied")
"""

'''
print ("But this one now will work!!")
'''

