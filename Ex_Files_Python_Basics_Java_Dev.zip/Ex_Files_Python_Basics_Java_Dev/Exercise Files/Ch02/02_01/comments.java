public class comments
{
  public static void main(String [] args)
  {
    System.out.println("Some lines start with a //");
    //This is a comment
    System.out.println(" This however /* is a multiline */ comment statement");

    /* Scanner scan = new Scanner (System.in);
     * int blah = scan.nextInt();
     */
    
    System.out.println(" This is how we comment in Java");
    }
}
 