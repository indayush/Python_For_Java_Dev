rows =10
i =1
star =1

for i in range (1,rows):
	for star in range (i):
		print ("*",end=" " )
	print()

