month = int (input ("Please enter the number of the month you want to know about" ))
OddOrEven = month % 2
