# Deepa Muralidhar
#1/12/2018
#I_OVariables -  A program to demonstrate use of different types of data read from the keyboard
name = input ("Please can you tell me your name" )
print ("Hi " + name + "please can you tell me how old you are?")
age = int (input ())
print ("Hi" + name + " So you are " + str (age) + " old. Can you tell me your height in feet and inches (eg. 4.8) ")
height = float (input ())
print ("So " + name + ", you are " + str (age) + " old and you are " + str (height))


