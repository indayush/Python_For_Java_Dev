public class hello
{
  public static void main (String [] arg)
  {
    System.out.print ("Hello");
  
  }
}